package com.kaapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.gyf.immersionbar.ImmersionBar;
import com.kaapp.util.SPUtils;

import butterknife.ButterKnife;
import butterknife.Unbinder;

// Fragment基类
public abstract class BaseFragment extends Fragment {

    private Unbinder unbinder;
    protected View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = getLayoutInflater().inflate(getLayout(), container, false);
        unbinder = ButterKnife.bind(this, view);
        ImmersionBar.with(this).statusBarDarkFont(true, 0.2f).init();
        initView();
        return view;
    }

    protected abstract int getLayout();

    protected abstract void initView();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    protected void toLinkPage(Class<?> clazz) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), clazz);
        startActivity(intent);
        getActivity().finish();
    }

    protected void toLinkPageNotFinished(Class<?> clazz) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), clazz);
        startActivity(intent);
    }

    protected void toLinkForResult(Class<?> clazz, int resultCode) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), clazz);
        startActivityForResult(intent, resultCode);
    }

    public void showToast(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    public String getKey(String key) {
        return (String) SPUtils.get(getActivity(), key, "");
    }

    protected void open(Context context, View editText) {
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.showSoftInput(editText, 0);
    }

    protected void close(Context context) {
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
    }

    public String getMessageByRes(int resId) {
        return view.getResources().getString(resId);
    }

    public String[] getArrayFromRes(int resId) {
        return view.getResources().getStringArray(resId);
    }
}
