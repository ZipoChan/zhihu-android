package com.kaapp.activity.home;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kaapp.BaseActivity;
import com.kaapp.R;
import com.kaapp.common.ConfirmEnum;
import com.kaapp.common.Res;
import com.kaapp.dialog.BottomAnswerDialog;
import com.kaapp.dialog.BottomCommentDialog;
import com.kaapp.manager.AttentionManager;
import com.kaapp.manager.ReplyManager;
import com.kaapp.model.Question;
import com.kaapp.model.Reply;
import com.kaapp.model.UserAttention;
import com.kaapp.util.SPUtils;

import java.io.ByteArrayInputStream;

import butterknife.BindView;
import butterknife.OnClick;

// 关注-热榜-详情
public class HotDetailActivity extends BaseActivity implements BottomAnswerDialog.ConfirmListener, BottomCommentDialog.OnCommentInterface {

    public static final String PARAM_QUESTION = "param_question";

    // 返回
    @BindView(R.id.ivBack)
    ImageView ivBack;
    // 回答题目
    @BindView(R.id.tvQuestionText)
    TextView tvQuestionText;
    // 回头人头像
    @BindView(R.id.ivUserAvatar)
    ImageView ivUserAvatar;
    // 回答人姓名
    @BindView(R.id.tvUserName)
    TextView tvUserName;
    // 时间
    @BindView(R.id.tvReleaseTime)
    TextView tvReleaseTime;
    // 关注按钮
    @BindView(R.id.btnAttention)
    Button btnAttention;
    // 回答内容
    @BindView(R.id.tvAnswerText)
    TextView tvAnswerText;
    // 下一个回答
    @BindView(R.id.ivNextAnswer)
    ImageView ivNextAnswer;
    // 底部-写回答
    @BindView(R.id.tvWriteAnswer)
    TextView tvWriteAnswer;
    // 底部-点赞
    @BindView(R.id.layoutLike)
    LinearLayout layoutLike;
    @BindView(R.id.ivLike)
    ImageView ivLike;
    @BindView(R.id.tvLikeCount)
    TextView tvLikeCount;
    // 底部-评论
    @BindView(R.id.layoutComment)
    LinearLayout layoutComment;
    @BindView(R.id.ivComment)
    ImageView ivComment;
    @BindView(R.id.tvCommentCount)
    TextView tvCommentCount;

    private Question question;
    private int targetRow;
    private ReplyManager replyManager;
    private boolean hasHumanReply;
    private String replyNo;
    private AttentionManager attentionManager;
    private UserAttention userAttention;
    private Reply reply;

    @Override
    protected int getLayout() {
        return R.layout.activity_hot_detail;
    }

    @Override
    protected void initView() {
        attentionManager = new AttentionManager(this);
        replyManager = new ReplyManager(this);
        // 接收参数
        receiveParameter();
        // 初始化标题
        initData();
        // 获取回答数据
        onLoad(question.getQuestionNo(), targetRow);
        loadCommentCount();
    }

    private void receiveParameter() {
        // 获取序列化参数
        question = (Question) getIntent().getSerializableExtra(PARAM_QUESTION);
    }

    private void initData() {
        tvQuestionText.setText(question.getQuestionText());
    }

    private void onLoad(String questionNo, int target) {
        reply = replyManager.queryReplyByQuestionNo(questionNo, targetRow);
        if (reply != null) {
            replyNo = reply.getReplyNo();
            hasHumanReply = true;
            // 用户信息
            ByteArrayInputStream in = new ByteArrayInputStream(reply.getUser().getAvatar());
            ivUserAvatar.setImageDrawable(Drawable.createFromStream(in, "img"));
            tvUserName.setText(reply.getUser().getUserName());
            tvReleaseTime.setText("");

            // 回答文本
            tvAnswerText.setText(reply.getAnswerText());

            // 点赞数和评论数
            tvLikeCount.setText(String.valueOf(reply.getLikeCount()));
            tvCommentCount.setText(String.valueOf(reply.getCommentCount()));
            btnAttention.setVisibility(View.VISIBLE);
            layoutLike.setVisibility(View.VISIBLE);
            layoutComment.setVisibility(View.VISIBLE);

            // 获取是否关注
            String userNo = (String) SPUtils.get(this, Res.setting.userNo, "");
            String otherNo = reply.getUserNo();
            if (TextUtils.isEmpty(otherNo) == false) {
                userAttention = attentionManager.queryAttentionByNo(userNo, otherNo);
                if (userAttention != null) {
                    btnAttention.setText("已关注");
                } else {
                    btnAttention.setText("关注");
                }
            } else {
                btnAttention.setText("关注");
            }
        } else {
            if (target == 0) {
                replyNo = "";
                btnAttention.setVisibility(View.INVISIBLE);
                layoutLike.setVisibility(View.INVISIBLE);
                layoutComment.setVisibility(View.INVISIBLE);
                hasHumanReply = false;
                showToast("暂时还没人回答");
            } else {
                showToast("没有回答了");
            }
        }
    }

    @OnClick({R.id.ivBack, R.id.ivNextAnswer, R.id.tvWriteAnswer, R.id.layoutLike, R.id.layoutComment, R.id.btnAttention})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivNextAnswer:
                onIvNextAnswerClick();
                break;
            case R.id.tvWriteAnswer:
                onTvWriteAnswerClick();
                break;
            case R.id.layoutLike:
                onIvLikeClick();
                break;
            case R.id.layoutComment:
                onIvCommentClick();
                break;
            case R.id.btnAttention:
                onBtnAttentionClick();
                break;
        }
    }

    // 下一个回答
    private void onIvNextAnswerClick() {
        if (hasHumanReply == false) {
            onLoad(question.getQuestionNo(), 0);
        } else {
            targetRow++;
            onLoad(question.getQuestionNo(), targetRow);
        }
    }

    // 底部-写回答
    private void onTvWriteAnswerClick() {
        BottomAnswerDialog dialog = new BottomAnswerDialog(this);
        dialog.show();
    }

    // 底部-点赞
    private void onIvLikeClick() {
        if (TextUtils.isEmpty(replyNo) == false) {
            int ret = replyManager.updateReplyByNo(replyNo);
            if (0 < ret) {
                int curLikeCount = Integer.parseInt(String.valueOf(tvLikeCount.getText()));
                curLikeCount++;
                tvLikeCount.setText(String.valueOf(curLikeCount));
            }
        } else {
            showToast("当前没有回答,无法点赞");
        }
    }

    // 底部-评论
    private void onIvCommentClick() {
        BottomCommentDialog dialog = new BottomCommentDialog(this);
        String userNo = (String) SPUtils.get(this, Res.setting.userNo, "");
        dialog.setValue(replyNo, userNo, question.getQuestionNo());
        dialog.show();
    }

    // 关注按钮
    private void onBtnAttentionClick() {
        if (userAttention != null) {
            int ret = attentionManager.deleteAttention(userAttention.getAttentionNo());
            if (0 < ret) {
                userAttention = null;
                btnAttention.setText("关注");
            }
        } else {
            String userNo = (String) SPUtils.get(this, Res.setting.userNo, "");
            String otherNo = reply.getUserNo();
            long ret = attentionManager.addAttention(userNo, otherNo);
            if (0 < ret) {
                userAttention = attentionManager.queryAttentionByNo(userNo, otherNo);
                btnAttention.setText("已关注");
            }
        }
    }

    // 底部-写回答回调
    @Override
    public void onConfirmClickLister(ConfirmEnum confirmEnum, String value) {
        if (TextUtils.isEmpty(value)) {
            showToast("请填写回答内容");
            return;
        }
        if (confirmEnum == ConfirmEnum.OK) {
            String replyNo = replyManager.queryMaxCode();
            String answerText = value;
            String userNo = (String) SPUtils.get(this, Res.setting.userNo, "");
            long ret = replyManager.addReply(replyNo, question.getQuestionNo(), answerText, userNo);
            if (0 < ret) {
                onIvNextAnswerClick();
            }
        }
    }

    @Override
    public void onCommentListener() {
        loadCommentCount();
    }

    private void loadCommentCount() {
        tvCommentCount.setText(String.valueOf(replyManager.queryCommentCountByNo(replyNo)));
    }
}

