package com.kaapp.common;

import android.os.Environment;

public class Res {

    public static class setting {
        public static final String userNo = "userNo";
        public static final String userName = "userName";
        public static final String password = "password";
        public static final String avatar = "avatar";
        public static final String searchHistory = "searchHistory";
    }

    public static class url {
        public static final String media_tool_collection = "MediaToolCollection";
        public static final String media_tool_pic = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + media_tool_collection + "/IMG";
    }

    public static class symbol {
        public static final String split = "@#@";
    }
}
