package com.kaapp.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;

import com.kaapp.db.DBManager;
import com.kaapp.model.User;
import com.kaapp.util.StringHelper;

// 用户
public class UserManager extends DBManager {
    public static final String TABLE_NAME = "tb_user";
    public static final String FIELD_USER_NO = "user_no";
    public static final String FIELD_USER_NAME = "user_name";
    public static final String FIELD_PASSWORD = "password";
    public static final String FIELD_AVATAR = "avatar";

    public UserManager(Context context) {
        super(context);
    }

    // 查询最大code
    public String queryMaxCode() {
        String maxCode = "";
        String sqlCmd = " select user_no from tb_user order by user_no desc limit 1 ";
        Cursor cursor = rawQuery(sqlCmd, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String userNo = cursor.getString(cursor.getColumnIndex(FIELD_USER_NO));
                String tmpCode = String.valueOf(Integer.parseInt(userNo) + 1);
                maxCode = StringHelper.padLeft(tmpCode, 4);
            }
            cursor.close();
        }
        // 如果最大Code是空,则编号自动为"0001"
        if (TextUtils.isEmpty(maxCode)) {
            maxCode = "0001";
        }
        return maxCode;
    }

    // 插入
    public long addUser(String userNo, String userName, String password, byte[] avatar) {
        ContentValues cvs = new ContentValues();
        cvs.put(FIELD_USER_NO, userNo);
        cvs.put(FIELD_USER_NAME, userName);
        cvs.put(FIELD_PASSWORD, password);
        cvs.put(FIELD_AVATAR, avatar);
        long ret = insert(TABLE_NAME, cvs);
        return ret;
    }

    public User queryUser(String userNo, String password) {
        String selection = " user_no = ? and password = ? ";
        String[] selArgs = new String[]{userNo, password};
        Cursor cursor = query(TABLE_NAME, selection, selArgs);
        User user = null;
        if (cursor != null) {
            cursor.moveToPosition(0);
            user = new User();
            String userName = cursor.getString(cursor.getColumnIndex(FIELD_USER_NAME));
            byte[] avatarByte = cursor.getBlob(cursor.getColumnIndex(FIELD_AVATAR));
            user.setUserNo(userNo);
            user.setUserName(userName);
            user.setPassword(password);
            user.setAvatar(avatarByte);

        }
        return user;
    }
}

