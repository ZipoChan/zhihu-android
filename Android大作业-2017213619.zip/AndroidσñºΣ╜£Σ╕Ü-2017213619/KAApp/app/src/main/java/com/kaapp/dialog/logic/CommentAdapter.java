package com.kaapp.dialog.logic;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kaapp.R;
import com.kaapp.manager.ReplyCommentManager;
import com.kaapp.model.ReplyComment;

import java.io.ByteArrayInputStream;
import java.util.List;

// 首页-热度-评论的适配器
public class CommentAdapter extends RecyclerView.Adapter {
    private Context context;
    private List<ReplyComment> replyCommentList;
    private ReplyCommentManager replyCommentManager;

    public CommentAdapter(Context context, List<ReplyComment> replyCommentList) {
        this.context = context;
        this.replyCommentList = replyCommentList;
        replyCommentManager = new ReplyCommentManager(context);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder holder = new NormalViewHolder(LayoutInflater.from(context).inflate(R.layout.dialog_comment_item, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        final NormalViewHolder normalHolder = (NormalViewHolder) holder;
        final ReplyComment replyComment = replyCommentList.get(position);
        ByteArrayInputStream in = new ByteArrayInputStream(replyComment.getUser().getAvatar());
        normalHolder.ivUserAvatar.setImageDrawable(Drawable.createFromStream(in, "img"));
        normalHolder.tvUserName.setText(replyComment.getUser().getUserName());
        int likeCount = replyComment.getLikeCount();
        normalHolder.tvLikeCount.setText(String.valueOf(likeCount));
        normalHolder.tvAnswerText.setText(replyComment.getAnswerText());
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int likeCount = replyComment.getLikeCount();
                int ret = replyCommentManager.updateReplyComment(replyComment.getReplyCommentNo());
                if (0 < ret) {
                    likeCount++;
                    replyComment.setLikeCount(likeCount);
                    normalHolder.tvLikeCount.setText(String.valueOf(likeCount));
//                    notifyDataSetChanged();
                }
            }
        };
        normalHolder.layoutLike.setOnClickListener(clickListener);
    }

    @Override
    public int getItemCount() {
        if (replyCommentList == null) {
            return 0;
        }
        return replyCommentList.size();
    }


    public class NormalViewHolder extends RecyclerView.ViewHolder {
        // 正常Item
        private ImageView ivUserAvatar;
        private TextView tvUserName;
        private LinearLayout layoutLike;
        private TextView tvLikeCount;
        private TextView tvAnswerText;

        public NormalViewHolder(@NonNull View itemView) {
            super(itemView);
            ivUserAvatar = itemView.findViewById(R.id.ivUserAvatar);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            layoutLike = itemView.findViewById(R.id.layoutLike);
            tvLikeCount = itemView.findViewById(R.id.tvLikeCount);
            tvAnswerText = itemView.findViewById(R.id.tvAnswerText);
        }
    }
}
