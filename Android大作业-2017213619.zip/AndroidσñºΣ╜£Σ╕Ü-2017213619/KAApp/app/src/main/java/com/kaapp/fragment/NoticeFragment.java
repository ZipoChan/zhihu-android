package com.kaapp.fragment;

import com.kaapp.BaseFragment;
import com.kaapp.R;

// 通知页面
public class NoticeFragment extends BaseFragment {

    @Override
    protected int getLayout() {
        return R.layout.fragment_notice;
    }

    @Override
    protected void initView() {

    }
}
