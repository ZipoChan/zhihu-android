package com.kaapp.util;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateHelper {
    private static final String PATTERN1 = "yyyyMMddHHmmss";
    private static final String PATTERN2 = "yyyy-MM-dd HH:mm:ss";

    private DateHelper() {
    }

    public static Date stringToDate(String str) {
        final String[] fmt = {"yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss"};
        for (String element : fmt) {
            DateFormat df = new SimpleDateFormat(element);
            try {
                Date d = df.parse(str);
                return d;
            } catch (ParseException e) {
            }
        }
        return null;
    }

    public static Calendar stringToCalendar(String str) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(stringToDate(str));
        return cal;
    }

    public static String format(Object o, String pattern) {
        if (o instanceof Date) {
            DateFormat df = new SimpleDateFormat(pattern);
            return df.format((Date) o);
        } else if (o instanceof Calendar) {
            DateFormat df = new SimpleDateFormat(pattern);
            return df.format(((Calendar) o).getTime());
        } else if (o instanceof String) {
            DateFormat df = new SimpleDateFormat(pattern);
            return df.format((stringToCalendar(String.valueOf(o))).getTime());
        }
        return "";
    }

    public static String toIsoDateFormat(Object o) {
        return DateFormatUtils.ISO_DATE_FORMAT.format(o);
    }

    public static String toIsoDateTimeFormat(Object o) {
        return DateFormatUtils.ISO_DATETIME_FORMAT.format(o);
    }

    public static Date now() {
        return Calendar.getInstance().getTime();
    }

    public static String nowIsoDateTimeFormat() {
        return toIsoDateTimeFormat(now());
    }

    public static String dispFormat(String date) {
        return format(stringToDate(date), PATTERN2);
    }

    public static String nowFormat() {
        return format(now(), PATTERN1);
    }

    public static int getYear() {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        return year;
    }
}
