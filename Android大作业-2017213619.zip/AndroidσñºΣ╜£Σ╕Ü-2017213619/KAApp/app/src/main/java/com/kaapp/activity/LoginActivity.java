package com.kaapp.activity;


import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.kaapp.BaseActivity;
import com.kaapp.MainActivity;
import com.kaapp.R;
import com.kaapp.common.Res;
import com.kaapp.manager.UserManager;
import com.kaapp.model.User;
import com.kaapp.util.SPUtils;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.runtime.Permission;

import butterknife.BindView;
import butterknife.OnClick;


// 登录页面
public class LoginActivity extends BaseActivity {

    @BindView(R.id.etUserNo)
    EditText etUserNo;
    @BindView(R.id.etPassword)
    EditText etPassword;
    @BindView(R.id.btnLogin)
    Button btnLogin;
    @BindView(R.id.tvNewUserReg)
    TextView tvNewUserReg;

    private UserManager userManager;

    @Override
    protected int getLayout() {
        return R.layout.activity_login;
    }

    @Override
    protected void initView() {
        AndPermission.with(this)
                .runtime()
                .permission(Permission.WRITE_EXTERNAL_STORAGE, Permission.READ_EXTERNAL_STORAGE, Permission.CAMERA)
                .start();

        userManager = new UserManager(this);
    }

    @OnClick({R.id.btnLogin, R.id.tvNewUserReg})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btnLogin:
                onBtnLoginClick();
                break;
            case R.id.tvNewUserReg:
                onTvNewUserRegClick();
                break;
        }
    }

    // 登录
    private void onBtnLoginClick() {
        String userNo = String.valueOf(etUserNo.getText());
        String password = String.valueOf(etPassword.getText());
        if (TextUtils.isEmpty(userNo) || TextUtils.isEmpty(password)) {
            showToast("内容不能为空");
            return;
        }
        User user = userManager.queryUser(userNo, password);
        if (user == null) {
            showToast("登录失败");
        } else {
            SPUtils.put(this, Res.setting.userNo, userNo);
            SPUtils.put(this, Res.setting.userName, user.getUserName());
            SPUtils.put(this, Res.setting.password, password);
            toLinkPage(MainActivity.class);
        }
    }

    // 注册
    private void onTvNewUserRegClick() {
        toLinkPageNotFinished(RegisterActivity.class);
    }
}
