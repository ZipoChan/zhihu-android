package com.kaapp.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;

import com.kaapp.db.DBManager;
import com.kaapp.model.Reply;
import com.kaapp.model.User;
import com.kaapp.util.DateUtil;
import com.kaapp.util.StringHelper;

// 回答
public class ReplyManager extends DBManager {
    public static final String TABLE_NAME = "tb_reply";
    public static final String FIELD_REPLY_NO = "reply_no";
    public static final String FIELD_QUESTION_NO = "question_no";
    public static final String FIELD_ANSWER_TEXT = "answer_text";
    public static final String FIELD_LIKE_COUNT = "like_count";
    public static final String FIELD_COMMENT_COUNT = "comment_count";
    public static final String FIELD_USER_NO = "user_no";
    public static final String FIELD_CREATE_TIME = "create_time";

    public ReplyManager(Context context) {
        super(context);
    }

    // 查询最大code
    public String queryMaxCode() {
        String maxCode = "";
        String sqlCmd = " select reply_no from tb_reply order by reply_no desc limit 1 ";
        Cursor cursor = rawQuery(sqlCmd, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String replyNo = cursor.getString(cursor.getColumnIndex(FIELD_REPLY_NO));
                String tmpCode = String.valueOf(Integer.parseInt(replyNo) + 1);
                maxCode = StringHelper.padLeft(tmpCode, 4);
            }
            cursor.close();
        }
        // 如果最大Code是空,则编号自动为"0001"
        if (TextUtils.isEmpty(maxCode)) {
            maxCode = "000001";
        }
        return maxCode;
    }

    // 针对提问,增加回答
    public long addReply(String replyNo,
                         String questionNo,
                         String answerText,
                         String userNo) {
        ContentValues cvs = new ContentValues();
        cvs.put(FIELD_REPLY_NO, replyNo);
        cvs.put(FIELD_QUESTION_NO, questionNo);
        cvs.put(FIELD_ANSWER_TEXT, answerText);
        cvs.put(FIELD_LIKE_COUNT, 0);
        cvs.put(FIELD_COMMENT_COUNT, 0);
        cvs.put(FIELD_USER_NO, userNo);
        cvs.put(FIELD_CREATE_TIME, DateUtil.nowFormat());
        long ret = insert(TABLE_NAME, cvs);
        return ret;
    }

    public int queryCommentCountByNo(String replyNo) {
        String sqlCmd = " select * from tb_reply where reply_no = '" + replyNo + "' ";
        Cursor cursor = rawQuery(sqlCmd, null);
        int commentCount = 0;
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                commentCount = cursor.getInt(cursor.getColumnIndex(FIELD_COMMENT_COUNT));
            }
            cursor.close();
        }
        return commentCount;
    }

    // 获取回答
    public Reply queryReplyByQuestionNo(String questionNo, int targetRow) {
        String sqlCmd = " select A.*, B.user_name, B.avatar from tb_reply A, tb_user B where question_no = '" + questionNo + "' and A.user_no = B.user_no order by A.create_time ";
        Cursor cursor = rawQuery(sqlCmd, null);
        Reply reply = null;
        if (cursor != null) {
            cursor.moveToPosition(-1);
            int curRow = 0;
            while (cursor.moveToNext()) {
                if (curRow == targetRow) {
                    String replyNo = cursor.getString(cursor.getColumnIndex(FIELD_REPLY_NO));
                    String answerText = cursor.getString(cursor.getColumnIndex(FIELD_ANSWER_TEXT));
                    int likeCount = cursor.getInt(cursor.getColumnIndex(FIELD_LIKE_COUNT));
                    int commentCount = cursor.getInt(cursor.getColumnIndex(FIELD_COMMENT_COUNT));
                    String userNo = cursor.getString(cursor.getColumnIndex(FIELD_USER_NO));
                    String userName = cursor.getString(cursor.getColumnIndex("user_name"));
                    byte[] avatarByte = cursor.getBlob(cursor.getColumnIndex("avatar"));
                    reply = new Reply();
                    reply.setReplyNo(replyNo);
                    reply.setUserNo(userNo);
                    reply.setAnswerText(answerText);
                    reply.setLikeCount(likeCount);
                    reply.setCommentCount(commentCount);
                    User user = new User();
                    user.setUserName(userName);
                    user.setAvatar(avatarByte);
                    reply.setUser(user);
                    break;
                }
                curRow++;
            }
            cursor.close();
        }
        return reply;
    }

    // 根据回答番号,更新数据
    public int updateReplyByNo(String replyNo) {
        String selection = " reply_no = ? ";
        String[] selArgs = new String[]{replyNo};
        Cursor cursor = query(TABLE_NAME, selection, selArgs);
        int ret = 0;
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                int likeCount = cursor.getInt(cursor.getColumnIndex(FIELD_LIKE_COUNT));
                likeCount++;
                ContentValues cvs = new ContentValues();
                cvs.put(FIELD_LIKE_COUNT, likeCount);
                ret = update(TABLE_NAME, cvs, selection, selArgs);
            }
            cursor.close();
        }
        return ret;
    }

    // 根据回答番号,更新数据
    public int updateReplyByNo2(String replyNo, int commentCount) {
        String selection = " reply_no = ? ";
        String[] selArgs = new String[]{replyNo};
        ContentValues cvs = new ContentValues();
        cvs.put(FIELD_COMMENT_COUNT, commentCount);
        int ret = update(TABLE_NAME, cvs, selection, selArgs);
        return ret;
    }
}

