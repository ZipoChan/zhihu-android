package com.kaapp.common;

public enum ConfirmEnum {
    OK,
    CANCEL
}
