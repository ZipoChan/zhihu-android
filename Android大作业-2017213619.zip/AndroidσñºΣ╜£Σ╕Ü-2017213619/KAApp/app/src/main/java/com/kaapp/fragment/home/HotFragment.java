package com.kaapp.fragment.home;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.kaapp.BaseFragment;
import com.kaapp.R;
import com.kaapp.activity.home.HotDetailActivity;
import com.kaapp.common.ConfirmEnum;
import com.kaapp.dialog.BottomAnswerDialog;
import com.kaapp.logic.hot.HotAdapter;
import com.kaapp.manager.QuestionManager;
import com.kaapp.model.Question;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

// 热榜
public class HotFragment extends BaseFragment implements HotAdapter.OnClickHotListener, BottomAnswerDialog.ConfirmListener {

    @BindView(R.id.srlHot)
    SmartRefreshLayout srlHot;
    @BindView(R.id.recyclerHot)
    RecyclerView recyclerHot;
    @BindView(R.id.ivAdd)
    ImageView ivAdd;

    private HotAdapter adapter;
    private QuestionManager questionManager;
    private List<Question> questionList;

    @Override
    protected int getLayout() {
        return R.layout.fragment_hot;
    }

    @Override
    protected void initView() {
        questionManager = new QuestionManager(getActivity());
        questionList = new ArrayList<>();
        initLayout();
        initListView();
        onLoad();
        srlHot.autoRefresh();
    }

    private void initLayout() {
        srlHot.setRefreshHeader(new ClassicsHeader(getActivity()));
        srlHot.setEnableLoadMore(false);
    }

    private void initListView() {
        recyclerHot.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new HotAdapter(getActivity(), questionList, this);
        recyclerHot.setAdapter(adapter);
    }

    private void onLoad() {
        srlHot.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                if (questionList == null) {
                    questionList = new ArrayList<>();
                } else {
                    questionList.clear();
                }
                questionList.addAll(questionManager.queryQuestionList());
                refreshLayout.finishRefresh();
                adapter.notifyDataSetChanged();
            }
        });
    }

    @OnClick({R.id.ivAdd})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivAdd:
                onIvAddClick();
                break;
        }
    }

    // 增加提问
    private void onIvAddClick() {
        BottomAnswerDialog dialog = new BottomAnswerDialog(this);
        dialog.show();
    }

    @Override
    public void onHotItemClick(int id, int position) {
        Question question = questionList.get(position);
        Intent intent = new Intent(getActivity(), HotDetailActivity.class);
        intent.putExtra(HotDetailActivity.PARAM_QUESTION, question);
        startActivity(intent);
    }

    @Override
    public void onConfirmClickLister(ConfirmEnum confirmEnum, String value) {
        // 发出提问
        if (confirmEnum == ConfirmEnum.OK) {
            if (TextUtils.isEmpty(value) == false) {
                String questionNo = questionManager.queryMaxCode();
                String questionText = value;
                long ret = questionManager.addQuestion(questionNo, questionText);
                if (0 < ret) {
                    srlHot.autoRefresh();
                }
            } else {
                showToast("请填写提问");
            }
        }
    }
}
