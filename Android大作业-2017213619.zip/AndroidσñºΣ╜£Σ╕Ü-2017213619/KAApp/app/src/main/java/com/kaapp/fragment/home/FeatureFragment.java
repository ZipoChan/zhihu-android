package com.kaapp.fragment.home;

import com.kaapp.BaseFragment;
import com.kaapp.R;

// 2020
public class FeatureFragment extends BaseFragment {

    @Override
    protected int getLayout() {
        return R.layout.fragment_feature;
    }

    @Override
    protected void initView() {

    }
}
