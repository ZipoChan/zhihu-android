package com.kaapp.fragment;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.kaapp.BaseFragment;
import com.kaapp.R;
import com.kaapp.activity.LoginActivity;
import com.kaapp.activity.me.AttentionActivity;
import com.kaapp.common.Res;
import com.kaapp.manager.UserManager;
import com.kaapp.model.User;
import com.kaapp.util.SPUtils;

import java.io.ByteArrayInputStream;

import butterknife.BindView;
import butterknife.OnClick;

// 我的页
public class MeFragment extends BaseFragment {

    @BindView(R.id.tvLogout)
    TextView tvLogout;
    @BindView(R.id.ivUserAvatar)
    ImageView ivUserAvatar;
    @BindView(R.id.tvUserName)
    TextView tvUserName;
    @BindView(R.id.tvLike)
    TextView tvLike;

    private UserManager userManager;
    private User user;

    @Override
    protected int getLayout() {
        return R.layout.fragment_me;
    }

    @Override
    protected void initView() {
        userManager = new UserManager(getActivity());
        String userNo = (String) SPUtils.get(getActivity(), Res.setting.userNo, "");
        String password = (String) SPUtils.get(getActivity(), Res.setting.password, "");
        user = userManager.queryUser(userNo, password);
        // 设置用户名和头像
        if (user != null) {
            tvUserName.setText("昵称: " + user.getUserName());
            ByteArrayInputStream in = new ByteArrayInputStream(user.getAvatar());
            ivUserAvatar.setImageDrawable(Drawable.createFromStream(in, "img"));
        }
    }

    @OnClick({R.id.tvLogout, R.id.tvLike})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.tvLogout:
                SPUtils.clear(getActivity());
                toLinkPage(LoginActivity.class);
                break;
            case R.id.tvLike:
                toLinkPageNotFinished(AttentionActivity.class);
                break;
        }
    }
}
