package com.kaapp.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;

import com.kaapp.db.DBManager;
import com.kaapp.model.ReplyComment;
import com.kaapp.model.User;
import com.kaapp.util.DateUtil;
import com.kaapp.util.StringHelper;

import java.util.ArrayList;
import java.util.List;

// 回答评论
public class ReplyCommentManager extends DBManager {
    public static final String TABLE_NAME = "tb_reply_comment";
    public static final String FIELD_REPLY_COMMENT_NO = "reply_comment_no";
    public static final String FIELD_ANSWER_TEXT = "answer_text";
    public static final String FIELD_LIKE_COUNT = "like_count";
    public static final String FIELD_USER_NO = "user_no";
    public static final String FIELD_QUESTION_NO = "question_no";
    public static final String FIELD_REPLY_NO = "reply_no";
    public static final String FIELD_CREATE_TIME = "create_time";

    public ReplyCommentManager(Context context) {
        super(context);
    }

    // 查询最大code
    public String queryMaxCode() {
        String maxCode = "";
        String sqlCmd = " select reply_comment_no from tb_reply_comment order by reply_comment_no desc limit 1 ";
        Cursor cursor = rawQuery(sqlCmd, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String replyCommentNo = cursor.getString(cursor.getColumnIndex(FIELD_REPLY_COMMENT_NO));
                String tmpCode = String.valueOf(Integer.parseInt(replyCommentNo) + 1);
                maxCode = StringHelper.padLeft(tmpCode, 4);
            }
            cursor.close();
        }
        // 如果最大Code是空,则编号自动为"0001"
        if (TextUtils.isEmpty(maxCode)) {
            maxCode = "00000001";
        }
        return maxCode;
    }

    // 查询集合
    public List<ReplyComment> queryReplyComments(String replyNo) {
        String sqlCmd = " select A.*, B.user_name, B.avatar from tb_reply_comment A, tb_user B where A.user_no = B.user_no and A.reply_no = '"+replyNo+"' order by create_time desc ";
        Cursor cursor = rawQuery(sqlCmd, null);
        List<ReplyComment> replyComments = new ArrayList<>();
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String replyCommentNo = cursor.getString(cursor.getColumnIndex(FIELD_REPLY_COMMENT_NO));
                String answerText = cursor.getString(cursor.getColumnIndex(FIELD_ANSWER_TEXT));
                int likeCount = cursor.getInt(cursor.getColumnIndex(FIELD_LIKE_COUNT));
                String userNo = cursor.getString(cursor.getColumnIndex(FIELD_USER_NO));
                String questionNo = cursor.getString(cursor.getColumnIndex(FIELD_QUESTION_NO));
                String createTime = cursor.getString(cursor.getColumnIndex(FIELD_CREATE_TIME));

                String userName = cursor.getString(cursor.getColumnIndex("user_name"));
                byte[] avatar = cursor.getBlob(cursor.getColumnIndex("avatar"));
                User user = new User();
                user.setUserNo(userNo);
                user.setUserName(userName);
                user.setAvatar(avatar);

                ReplyComment replyComment = new ReplyComment();
                replyComment.setReplyCommentNo(replyCommentNo);
                replyComment.setAnswerText(answerText);
                replyComment.setLikeCount(likeCount);
                replyComment.setUserNo(userNo);
                replyComment.setQuestionNo(questionNo);
                replyComment.setCreateTime(createTime);
                replyComment.setUser(user);

                replyComments.add(replyComment);
            }
            cursor.close();
        }
        return replyComments;
    }

    // 添加评论
    public long addReplyComment(String answerText, String userNo, String replyNo, String questionNo) {
        ContentValues cvs = new ContentValues();
        cvs.put(FIELD_REPLY_COMMENT_NO, queryMaxCode());
        cvs.put(FIELD_ANSWER_TEXT, answerText);
        cvs.put(FIELD_LIKE_COUNT, 0);
        cvs.put(FIELD_USER_NO, userNo);
        cvs.put(FIELD_QUESTION_NO, questionNo);
        cvs.put(FIELD_REPLY_NO, replyNo);
        cvs.put(FIELD_CREATE_TIME, DateUtil.nowFormat());
        long ret = insert(TABLE_NAME, cvs);
        return ret;
    }

    // 对评论点赞
    public int updateReplyComment(String replyCommentNo) {
        String selection = " reply_comment_no = ? ";
        String[] selArgs = new String[]{replyCommentNo};
        Cursor cursor = query(TABLE_NAME, selection, selArgs);
        int ret = 0;
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                int likeCount = Integer.parseInt(cursor.getString(cursor.getColumnIndex(FIELD_LIKE_COUNT)));
                likeCount++;
                ContentValues cvs = new ContentValues();
                cvs.put(FIELD_LIKE_COUNT, likeCount);
                ret = update(TABLE_NAME, cvs, selection, selArgs);
            }
        }
        return ret;
    }
}

