package com.kaapp.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;

import com.kaapp.db.DBManager;
import com.kaapp.model.Question;
import com.kaapp.util.StringHelper;

import java.util.ArrayList;
import java.util.List;

// 问题
public class QuestionManager extends DBManager {
    public static final String TABLE_NAME = "tb_question";
    public static final String FIELD_QUESTION_NO = "question_no";
    public static final String FIELD_QUESTION_TEXT = "question_text";

    public QuestionManager(Context context) {
        super(context);
    }

    // 查询最大code
    public String queryMaxCode() {
        String maxCode = "";
        String sqlCmd = " select question_no from tb_question order by question_no desc limit 1 ";
        Cursor cursor = rawQuery(sqlCmd, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String questionNo = cursor.getString(cursor.getColumnIndex(FIELD_QUESTION_NO));
                String tmpCode = String.valueOf(Integer.parseInt(questionNo) + 1);
                maxCode = StringHelper.padLeft(tmpCode, 4);
            }
            cursor.close();
        }
        // 如果最大Code是空,则编号自动为"0001"
        if (TextUtils.isEmpty(maxCode)) {
            maxCode = "0001";
        }
        return maxCode;
    }

    // 增加提问
    public long addQuestion(String questionNo, String questionText) {
        ContentValues cvs = new ContentValues();
        cvs.put(FIELD_QUESTION_NO, questionNo);
        cvs.put(FIELD_QUESTION_TEXT, questionText);
        long ret = insert(TABLE_NAME, cvs);
        return ret;
    }

    // 获取提问一览
    public List<Question> queryQuestionList() {
        List<Question> questionList = new ArrayList<>();
        Cursor cursor = query(TABLE_NAME, null, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String questionNo = cursor.getString(cursor.getColumnIndex(FIELD_QUESTION_NO));
                String questionText = cursor.getString(cursor.getColumnIndex(FIELD_QUESTION_TEXT));
                Question question = new Question();
                question.setQuestionNo(questionNo);
                question.setQuestionText(questionText);
                questionList.add(question);
            }
            cursor.close();
        }
        return questionList;
    }

}

