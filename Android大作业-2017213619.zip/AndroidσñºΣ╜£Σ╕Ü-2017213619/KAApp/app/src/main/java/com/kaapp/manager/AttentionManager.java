package com.kaapp.manager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.text.TextUtils;

import com.kaapp.db.DBManager;
import com.kaapp.model.UserAttention;
import com.kaapp.util.StringHelper;

// 关注
public class AttentionManager extends DBManager {
    public static final String TABLE_NAME = "tb_attention";
    public static final String FIELD_ATTENTION_NO = "attention_no";
    public static final String FIELD_USER_NO = "user_no";
    public static final String FIELD_OTHER_NO = "other_no";

    public AttentionManager(Context context) {
        super(context);
    }

    // 查询最大code
    public String queryMaxCode() {
        String maxCode = "";
        String sqlCmd = " select attention_no from tb_attention order by attention_no desc limit 1 ";
        Cursor cursor = rawQuery(sqlCmd, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                String attentionNo = cursor.getString(cursor.getColumnIndex(FIELD_ATTENTION_NO));
                String tmpCode = String.valueOf(Integer.parseInt(attentionNo) + 1);
                maxCode = StringHelper.padLeft(tmpCode, 4);
            }
            cursor.close();
        }
        // 如果最大Code是空,则编号自动为"0001"
        if (TextUtils.isEmpty(maxCode)) {
            maxCode = "0000001";
        }
        return maxCode;
    }

    public UserAttention queryAttentionByNo(String userNo, String otherNo) {
        String selection = " user_no = ? and other_no = ? ";
        String[] selArgs = new String[]{userNo, otherNo};
        Cursor cursor = query(TABLE_NAME, selection, selArgs);
        UserAttention userAttention = null;
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                userAttention = new UserAttention();
                String attentionNo = cursor.getString(cursor.getColumnIndex(FIELD_ATTENTION_NO));
                userAttention.setAttentionNo(attentionNo);
                userAttention.setUserNo(userNo);
                userAttention.setAttentionNo(attentionNo);
            }
        }
        return userAttention;
    }

    public long addAttention(String userNo, String otherNo) {
        ContentValues cvs = new ContentValues();
        cvs.put(FIELD_ATTENTION_NO, queryMaxCode());
        cvs.put(FIELD_USER_NO, userNo);
        cvs.put(FIELD_OTHER_NO, otherNo);
        return insert(TABLE_NAME, cvs);
    }

    public int deleteAttention(String attentionNo) {
        String whereCause = " attention_no = ? ";
        String[] whereArgs = new String[]{attentionNo};
        return delete(TABLE_NAME, whereCause, whereArgs);
    }
}

