package com.kaapp.logic.me;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kaapp.R;

// 用户关注适配器
public class UserAttentionAdapter extends RecyclerView.Adapter {
    private Context context;
    private OnClickUserAttentionListener onClickUserAttentionListener;

    public UserAttentionAdapter(Context context, OnClickUserAttentionListener onClickUserAttentionListener) {
        this.context = context;
        this.onClickUserAttentionListener = onClickUserAttentionListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder holder = new NormalViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_attention_user_item, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        NormalViewHolder normalHolder = (NormalViewHolder) holder;
//        ProductModel product = productList.get(position);
//        ImageUtils.loadImgByUrl(holder.ivLevelThumb, Res.http.picRoot + product.getPic1());
//        holder.tvLevelTitle.setText(product.getName());
//        holder.tvConsumeScore.setText(String.valueOf(product.getScore()));
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickUserAttentionListener.onUserAttentionItemClick(v.getId(), position);
            }
        };
        normalHolder.layoutUserAttention.setOnClickListener(clickListener);
    }

    @Override
    public int getItemCount() {
//        if (productList == null) {
//            return 0;
//        }
//        return productList.size();
        return 10;
    }


    public class NormalViewHolder extends RecyclerView.ViewHolder {
        // 正常Item
        private LinearLayout layoutUserAttention;
        private ImageView ivUserAvatar;
        private TextView tvUserName;
        private TextView tvAnswerText;

        public NormalViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutUserAttention = itemView.findViewById(R.id.layoutUserAttention);
            ivUserAvatar = itemView.findViewById(R.id.ivUserAvatar);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvAnswerText = itemView.findViewById(R.id.tvAnswerText);
        }
    }


    public interface OnClickUserAttentionListener {
        void onUserAttentionItemClick(int id, int position);
    }
}
