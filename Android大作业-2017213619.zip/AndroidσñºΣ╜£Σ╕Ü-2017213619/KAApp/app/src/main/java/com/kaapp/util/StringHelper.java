package com.kaapp.util;

import org.apache.commons.lang3.StringUtils;

public class StringHelper {
	// 左补0
	public static String padLeft(String orginalString, int totalWidth) {
		if (StringUtils.isEmpty(orginalString) == true) {
			orginalString = "";
		}
		orginalString = orginalString.trim();
		if (totalWidth <= orginalString.length()) {
			return orginalString;
		}

		StringBuilder sb = new StringBuilder(totalWidth);
		int fill = totalWidth - orginalString.length();

		for (int i = 0; i < fill; i++) {
			sb.append("0");
		}

		sb.append(orginalString);
		return sb.toString();
	}
}
