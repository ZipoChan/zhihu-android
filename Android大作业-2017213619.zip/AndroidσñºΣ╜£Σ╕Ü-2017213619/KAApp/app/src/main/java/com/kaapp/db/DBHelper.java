package com.kaapp.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.kaapp.util.Util;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "Info.DB";

    public static final int DB_VERSION = 1;
    private Context context;

    public DBHelper(Context context) {
        this(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTables(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    private void createTables(SQLiteDatabase db) {
        createTable(db);
    }

    private void createTable(SQLiteDatabase db) {
        // 聊天室
        String chatSql = Util.readAssets(context, "sql/chat.sql");
        db.execSQL(chatSql);
        // 想法
        String ideaSql = Util.readAssets(context, "sql/idea.sql");
        db.execSQL(ideaSql);
        // 想法评论
        String ideaCommentSql = Util.readAssets(context, "sql/idea_comment.sql");
        db.execSQL(ideaCommentSql);
        // 问题
        String questionSql = Util.readAssets(context, "sql/question.sql");
        db.execSQL(questionSql);
        // 回答
        String replySql = Util.readAssets(context, "sql/reply.sql");
        db.execSQL(replySql);
        // 回答评论
        String replyCommentSql = Util.readAssets(context, "sql/reply_comment.sql");
        db.execSQL(replyCommentSql);
        // 用户
        String userSql = Util.readAssets(context, "sql/user.sql");
        db.execSQL(userSql);
        // 关注
        String attentionSql = Util.readAssets(context, "sql/user_attention.sql");
        db.execSQL(attentionSql);
    }
}
