package com.kaapp.logic;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.kaapp.R;

import java.util.List;

// 检索适配器
public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {

    private Context context;
    private List<String> historyList;
    private OnClickHistoryListener onClickHistoryListener;

    public SearchAdapter(Context context, List<String> historyList, OnClickHistoryListener onClickHistoryListener) {
        this.context = context;
        this.historyList = historyList;
        this.onClickHistoryListener = onClickHistoryListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.search_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        String content = historyList.get(position);
        holder.tvHistoryItem.setText(content);

        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickHistoryListener.onHistoryItemClick(v.getId(), position);
            }
        };
        holder.tvHistoryItem.setOnClickListener(clickListener);
    }

    @Override
    public int getItemCount() {
        if (historyList == null) {
            return 0;
        }
        return historyList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvHistoryItem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvHistoryItem = itemView.findViewById(R.id.tvHistoryItem);
        }
    }

    public interface OnClickHistoryListener {
        void onHistoryItemClick(int id, int position);
    }
}
