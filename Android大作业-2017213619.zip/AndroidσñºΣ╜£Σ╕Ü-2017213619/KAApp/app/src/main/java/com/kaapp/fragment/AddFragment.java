package com.kaapp.fragment;

import com.kaapp.BaseFragment;
import com.kaapp.R;

// 增加页
public class AddFragment extends BaseFragment {

    @Override
    protected int getLayout() {
        return R.layout.fragment_add;
    }

    @Override
    protected void initView() {

    }

}
