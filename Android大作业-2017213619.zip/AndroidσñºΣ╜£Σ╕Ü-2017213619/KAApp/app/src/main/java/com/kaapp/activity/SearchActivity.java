package com.kaapp.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.kaapp.BaseActivity;
import com.kaapp.R;
import com.kaapp.common.Res;
import com.kaapp.logic.SearchAdapter;
import com.kaapp.util.SPUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

// 检索
public class SearchActivity extends BaseActivity implements SearchAdapter.OnClickHistoryListener {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.etSearch)
    EditText etSearch;
    @BindView(R.id.btnSearch)
    Button btnSearch;
    @BindView(R.id.ivTrash)
    ImageView ivTrash;
    @BindView(R.id.recycleSearch)
    RecyclerView recycleSearch;

    private List<String> historyList;
    private String searchHistory;
    private SearchAdapter adapter;

    @Override
    protected int getLayout() {
        return R.layout.activity_search;
    }

    @Override
    protected void initView() {
        historyList = new ArrayList<>();
        initListView();
        onLoad();
    }

    private void initListView() {
        recycleSearch.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SearchAdapter(this, historyList, this);
        recycleSearch.setAdapter(adapter);
    }

    // 加载数据源
    private void onLoad() {
        searchHistory = (String) SPUtils.get(this, Res.setting.searchHistory, "");
        historyList = Arrays.asList(searchHistory.split(Res.symbol.split));
        List<String> newList = new ArrayList<>();
        for (String content : historyList) {
            if (newList.contains(content) == false) {
                newList.add(content);
            }
        }
        adapter.notifyDataSetChanged();
    }

    @OnClick({R.id.ivBack, R.id.ivTrash, R.id.btnSearch})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivTrash:
                onIvTrashClick();
                break;
            case R.id.btnSearch:
                onBtnSearchClick();
                break;
        }
    }

    private void onIvTrashClick() {

    }

    // 检索
    private void onBtnSearchClick() {
//        String searchContent = String.valueOf(editTextSearch.getText());
//        String title = getString(R.string.dialog_warning_tilte);
//        if (TextUtils.isEmpty(searchContent) == true) {
//            String content = "请输入检索内容";
//            showWarningDialog(id, title, content, true);
//        } else {
//            if (TextUtils.isEmpty(searchHistory)) {
//                searchHistory = searchContent;
//            } else {
//                searchHistory += Res.symbol.split + searchContent;
//            }
//            SPUtils.put(this, Res.param.searchHistory, searchHistory);
//            toSearchResult(searchContent);
//        }
    }

    @Override
    public void onHistoryItemClick(int id, int position) {

    }
}
