package com.kaapp.fragment;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.astuetz.PagerSlidingTabStrip;
import com.kaapp.BaseFragment;
import com.kaapp.R;
import com.kaapp.activity.SearchActivity;
import com.kaapp.fragment.home.AttentionFragment;
import com.kaapp.fragment.home.HotFragment;
import com.kaapp.fragment.home.IdeaFragment;
import com.kaapp.fragment.home.FeatureFragment;
import com.kaapp.logic.CommonPagerAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

// 首页
public class HomeFragment extends BaseFragment implements ViewPager.OnPageChangeListener {

    @BindView(R.id.layoutSearch)
    LinearLayout layoutSearch;
    @BindView(R.id.pagerHome)
    ViewPager pagerHome;
    private PagerSlidingTabStrip tabHome;

    @Override
    protected int getLayout() {
        return R.layout.fragment_home;
    }

    @Override
    protected void initView() {
        tabHome = view.findViewById(R.id.tabHome);
        initPageSliding();
        initTabs();
    }

    private void initPageSliding() {
        tabHome.setIndicatorColor(getResources().getColor(R.color.colorBlack, null));
    }

    private void initTabs() {
        List<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(new AttentionFragment());
        fragmentList.add(new IdeaFragment());
        fragmentList.add(new HotFragment());
        fragmentList.add(new FeatureFragment());
        List<String> titleList = Arrays.asList(getArrayFromRes(R.array.array_home_type));
        CommonPagerAdapter adapter = new CommonPagerAdapter(getActivity().getSupportFragmentManager(), titleList, fragmentList);
        pagerHome.setAdapter(adapter);
        tabHome.setViewPager(pagerHome);
        tabHome.setOnPageChangeListener(this);
        final int pageMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 4, getResources()
                .getDisplayMetrics());
        pagerHome.setPageMargin(pageMargin);
        pagerHome.setCurrentItem(0);
        setSelectColor(0);
    }

    @OnClick(R.id.layoutSearch)
    public void onClickViewq(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.layoutSearch:
                toLinkPageNotFinished(SearchActivity.class);
                break;
         }
    }

    @Override
    public void onPageScrolled(int i, float v, int i1) {

    }

    @Override
    public void onPageSelected(int position) {
        setSelectColor(position);
    }

    @Override
    public void onPageScrollStateChanged(int i) {

    }

    private void setSelectColor(int selectedPos) {
        int tabCount = tabHome.getTabCount();
        for (int i = 0; i < tabCount; i++) {
            setColor(i, getResources().getColor(R.color.text_color_detail_selected, null));
        }
        setColor(selectedPos, getResources().getColor(R.color.colorBlack, null));
    }

    private void setColor(int position, int colorRes) {
        View tab = tabHome.getTabsContainer().getChildAt(position);
        if (tab != null) {
            TextView tabTitle = tab.findViewById(R.id.psts_tab_title);
            tabTitle.setTextColor(colorRes);
        }
    }
}
