package com.kaapp.dialog;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.kaapp.R;
import com.kaapp.dialog.logic.CommentAdapter;
import com.kaapp.manager.ReplyCommentManager;
import com.kaapp.manager.ReplyManager;
import com.kaapp.model.ReplyComment;

import java.util.ArrayList;
import java.util.List;

// 底部评论对话框
public class BottomCommentDialog extends BottomDialogBase implements View.OnClickListener {

    private EditText etComment;
    private RecyclerView recyclerComment;
    private Context context;
    private String replyNo;
    private String userNo;
    private String questionNo;
    private ReplyCommentManager replyCommentManager;
    private ReplyManager replyManager;
    private List<ReplyComment> replyComments;
    private CommentAdapter adapter;
    private OnCommentInterface onCommentInterface;

    public BottomCommentDialog(Context context) {
        super(context);
        this.context = context;
        this.onCommentInterface = (OnCommentInterface) context;
    }

    public BottomCommentDialog(Fragment fragment) {
        super(fragment.getActivity());
        this.context = fragment.getActivity();
        this.onCommentInterface = (OnCommentInterface) fragment;
    }

    public void setValue(String replyNo, String userNo, String questionNo) {
        this.replyNo = replyNo;
        this.userNo = userNo;
        this.questionNo = questionNo;
    }

    @Override
    protected void onCreate() {
        setContentView(R.layout.dialog_comment);
        etComment = findViewById(R.id.etComment);
        recyclerComment = findViewById(R.id.recyclerComment);
        findViewById(R.id.tvOk).setOnClickListener(this);
    }

    @Override
    public void show() {
        super.show();
        replyManager = new ReplyManager(context);
        replyCommentManager = new ReplyCommentManager(context);
        replyComments = new ArrayList<>();
        adapter = new CommentAdapter(context, replyComments);
        recyclerComment.setLayoutManager(new LinearLayoutManager(context));
        recyclerComment.setAdapter(adapter);
        replyComments.addAll(replyCommentManager.queryReplyComments(replyNo));
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.tvOk:
                onTvOkClick();
                break;
        }
    }

    // 评论
    private void onTvOkClick() {
        String answerText = String.valueOf(etComment.getText());
        if (TextUtils.isEmpty(answerText) == false) {
            long ret = replyCommentManager.addReplyComment(answerText, userNo, replyNo, questionNo);
            if (0 < ret) {
                etComment.setText("");
                replyComments.clear();
                replyComments.addAll(replyCommentManager.queryReplyComments(replyNo));
                adapter.notifyDataSetChanged();
            }
        }
    }

    public interface OnCommentInterface {
        void onCommentListener();
    }

    @Override
    public void dismiss() {
        super.dismiss();
        replyManager.updateReplyByNo2(replyNo, replyComments.size());
        onCommentInterface.onCommentListener();
    }
}
