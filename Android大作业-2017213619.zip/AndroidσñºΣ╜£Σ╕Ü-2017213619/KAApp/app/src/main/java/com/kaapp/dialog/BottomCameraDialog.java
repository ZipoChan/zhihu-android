package com.kaapp.dialog;

import android.content.Context;
import android.view.View;

import com.kaapp.R;
import com.kaapp.common.CameraEnum;

// 底部弹出相机对话框
public class BottomCameraDialog extends BottomDialogBase implements View.OnClickListener {

    private CameraListener cameraListener;

    public BottomCameraDialog(Context context) {
        super(context);
        cameraListener = (CameraListener) context;
    }

    @Override
    protected void onCreate() {
        setContentView(R.layout.dialog_camera);
        findViewById(R.id.tvCameraTakePhoto).setOnClickListener(this);
        findViewById(R.id.tvCameraPicture).setOnClickListener(this);
        findViewById(R.id.tvCameraCancel).setOnClickListener(this);
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void onClick(View v) {
        dismiss();
        int id = v.getId();
        switch (id) {
            case R.id.tvCameraTakePhoto:
                cameraListener.onTakePhotoClickLister(CameraEnum.CAMERA);
                break;
            case R.id.tvCameraPicture:
                cameraListener.onTakePhotoClickLister(CameraEnum.GALLEY);
                break;
        }
    }

    public interface CameraListener {
        void onTakePhotoClickLister(CameraEnum cameraEnum);
    }
}
