package com.kaapp.model;

import java.io.Serializable;

// 关注
public class UserAttention implements Serializable {
    private String attentionNo;
    private String userNo;
    private String otherNo;

    public String getAttentionNo() {
        return attentionNo;
    }

    public void setAttentionNo(String attentionNo) {
        this.attentionNo = attentionNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getOtherNo() {
        return otherNo;
    }

    public void setOtherNo(String otherNo) {
        this.otherNo = otherNo;
    }
}
