package com.kaapp.logic.hot;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kaapp.R;
import com.kaapp.model.Question;

import java.util.List;

// 首页-热度的适配器
public class HotAdapter extends RecyclerView.Adapter {
    private Context context;
    private OnClickHotListener onClickHotListener;
    private List<Question> questionList;

    public HotAdapter(Context context, List<Question> questionList, OnClickHotListener onClickHotListener) {
        this.context = context;
        this.questionList = questionList;
        this.onClickHotListener = onClickHotListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder holder = new NormalViewHolder(LayoutInflater.from(context).inflate(R.layout.fragment_hot_list_item, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        NormalViewHolder normalHolder = (NormalViewHolder) holder;
        Question question = questionList.get(position);
        if (position < 3) {
            normalHolder.tvRankNumber.setText(String.valueOf(position + 1));
        }
        normalHolder.tvQuestionTitle.setText(question.getQuestionText());
        normalHolder.tvHotCount.setText(String.valueOf(0));
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickHotListener.onHotItemClick(v.getId(), position);
            }
        };
        normalHolder.layoutHot.setOnClickListener(clickListener);
    }

    @Override
    public int getItemCount() {
        if (questionList == null) {
            return 0;
        }
        return questionList.size();
    }


    public class NormalViewHolder extends RecyclerView.ViewHolder {
        // 正常Item
        private LinearLayout layoutHot;
        private TextView tvRankNumber;
        private TextView tvQuestionTitle;
        private TextView tvHotCount;

        public NormalViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutHot = itemView.findViewById(R.id.layoutHot);
            tvRankNumber = itemView.findViewById(R.id.tvRankNumber);
            tvQuestionTitle = itemView.findViewById(R.id.tvQuestionTitle);
            tvHotCount = itemView.findViewById(R.id.tvHotCount);
        }
    }

    public interface OnClickHotListener {
        void onHotItemClick(int id, int position);
    }
}
