package com.kaapp;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.kaapp.fragment.AddFragment;
import com.kaapp.fragment.HomeFragment;
import com.kaapp.fragment.MeFragment;
import com.kaapp.fragment.NoticeFragment;
import com.kaapp.fragment.VipFragment;
import com.zaaach.tabradiobutton.TabRadioButton;

import butterknife.BindView;
import butterknife.OnClick;

// 主页
public class MainActivity extends BaseActivity {

    // 首页
    @BindView(R.id.trbHome)
    TabRadioButton trbHome;
    // vip页面
    @BindView(R.id.trbVip)
    TabRadioButton trbVip;
    // 增加页面
    @BindView(R.id.trbAdd)
    TabRadioButton trbAdd;
    // 通知页面
    @BindView(R.id.trbNotice)
    TabRadioButton trbNotice;
    // 我的页面
    @BindView(R.id.trbMe)
    TabRadioButton trbMe;

    private Fragment homeFragment = new HomeFragment();
    private Fragment vipFragment = new VipFragment();
    private Fragment addFragment = new AddFragment();
    private Fragment noticeFragment = new NoticeFragment();
    private Fragment meFragment = new MeFragment();
    private static Fragment currentFragment = new Fragment();

    @Override
    protected int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        trbHome.setChecked(true);
        trbVip.setChecked(false);
        trbAdd.setChecked(false);
        trbNotice.setChecked(false);
        trbMe.setChecked(false);
        switchFragment(homeFragment).commit();
    }

    public FragmentTransaction switchFragment(Fragment targetFragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (targetFragment.isAdded() == false) {
            if (currentFragment != null) {
                transaction.hide(currentFragment);
            }
            transaction.add(R.id.fragment, targetFragment, targetFragment.getClass().getName());
        } else {
            transaction.hide(currentFragment).show(targetFragment);
        }
        currentFragment = targetFragment;
        return transaction;
    }

    @OnClick({R.id.trbHome, R.id.trbVip, R.id.trbAdd, R.id.trbNotice, R.id.trbMe})
    public void onViewClicked(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.trbHome:
                switchFragment(homeFragment).commit();
                break;
            case R.id.trbVip:
                switchFragment(vipFragment).commit();
                break;
            case R.id.trbAdd:
                switchFragment(addFragment).commit();
                break;
            case R.id.trbNotice:
                switchFragment(noticeFragment).commit();
                break;
            case R.id.trbMe:
                switchFragment(meFragment).commit();
                break;
        }
    }
}
