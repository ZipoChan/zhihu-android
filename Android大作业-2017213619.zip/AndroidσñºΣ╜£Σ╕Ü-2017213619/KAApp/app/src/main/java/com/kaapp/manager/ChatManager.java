package com.kaapp.manager;

import android.content.Context;

import com.kaapp.db.DBManager;

// 聊天
public class ChatManager  extends DBManager {
    public static final String TABLE_NAME = "tb_chat";
    public static final String FIELD_CHAT_ID = "chat_id";
    public static final String FIELD_SENDER_NO = "sender_no";
    public static final String FIELD_RECEIVER_NO = "receiver_no";
    public static final String FIELD_CREATE_TIME = "create_time";

    public ChatManager(Context context) {
        super(context);
    }

//    // 查询最大code
//    public String queryMaxCode() {
//        String maxCode = "";
//        String sqlCmd = " select info_no from tb_info order by info_no desc limit 1 ";
//        Cursor cursor = rawQuery(sqlCmd, null);
//        if (cursor != null) {
//            cursor.moveToPosition(-1);
//            while (cursor.moveToNext()) {
//                String userNo = cursor.getString(cursor.getColumnIndex(FIELD_INFO_NO));
//                String tmpCode = String.valueOf(Integer.parseInt(userNo) + 1);
//                maxCode = StringHelper.padLeft(tmpCode, 4);
//            }
//            cursor.close();
//        }
//        // 如果最大Code是空,则编号自动为"0001"
//        if (TextUtils.isEmpty(maxCode)) {
//            maxCode = "0001";
//        }
//        return maxCode;
//    }
}

