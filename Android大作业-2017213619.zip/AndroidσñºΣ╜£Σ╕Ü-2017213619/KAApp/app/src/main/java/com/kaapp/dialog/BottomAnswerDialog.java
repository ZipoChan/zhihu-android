package com.kaapp.dialog;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.EditText;

import com.kaapp.R;
import com.kaapp.common.ConfirmEnum;

// 底部回答对话框
public class BottomAnswerDialog extends BottomDialogBase implements View.OnClickListener {

    private ConfirmListener confirmListener;
    private EditText etAnswer;

    public BottomAnswerDialog(Context context) {
        super(context);
        confirmListener = (ConfirmListener) context;
    }

    public BottomAnswerDialog(Fragment fragment) {
        super(fragment.getActivity());
        confirmListener = (ConfirmListener) fragment;
    }

    @Override
    protected void onCreate() {
        setContentView(R.layout.dialog_answer);
        etAnswer = findViewById(R.id.etAnswer);
        findViewById(R.id.tvCancel).setOnClickListener(this);
        findViewById(R.id.tvOk).setOnClickListener(this);
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void onClick(View v) {
        dismiss();
        int id = v.getId();
        switch (id) {
            case R.id.tvCancel:
                confirmListener.onConfirmClickLister(ConfirmEnum.CANCEL, null);
                break;
            case R.id.tvOk:
                confirmListener.onConfirmClickLister(ConfirmEnum.OK, String.valueOf(etAnswer.getText()));
                break;
        }
    }

    public interface ConfirmListener {
        void onConfirmClickLister(ConfirmEnum confirmEnum, String value);
    }
}
