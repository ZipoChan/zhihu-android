package com.kaapp.logic.idea;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kaapp.R;

// 首页-想法的适配器
public class IdeaAdapter extends RecyclerView.Adapter {
    private Context context;
    private OnClickAttentionListener onClickAttentionListener;

    public IdeaAdapter(Context context, OnClickAttentionListener onClickAttentionListener) {
        this.context = context;
        this.onClickAttentionListener = onClickAttentionListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder holder = new NormalViewHolder(LayoutInflater.from(context).inflate(R.layout.fragment_idea_list_item, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        NormalViewHolder normalHolder = (NormalViewHolder) holder;
//        ProductModel product = productList.get(position);
//        ImageUtils.loadImgByUrl(holder.ivLevelThumb, Res.http.picRoot + product.getPic1());
//        holder.tvLevelTitle.setText(product.getName());
//        holder.tvConsumeScore.setText(String.valueOf(product.getScore()));
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickAttentionListener.onAttentionItemClick(v.getId(), position);
            }
        };
        normalHolder.layoutIdea.setOnClickListener(clickListener);
        normalHolder.layoutLike.setOnClickListener(clickListener);
        normalHolder.tvComment.setOnClickListener(clickListener);
    }

    @Override
    public int getItemCount() {
//        if (productList == null) {
//            return 0;
//        }
//        return productList.size();
        return 10;
    }


    public class NormalViewHolder extends RecyclerView.ViewHolder {
        // 正常Item
        private LinearLayout layoutIdea;
        private ImageView ivUserAvatar;
        private TextView tvUserName;
        private TextView tvReleaseTime;
        private TextView tvQuestionText;
        private LinearLayout layoutLike;
        private TextView tvLike;
        private LinearLayout layoutComment;
        private TextView tvComment;

        public NormalViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutIdea = itemView.findViewById(R.id.layoutIdea);
            ivUserAvatar = itemView.findViewById(R.id.ivUserAvatar);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvReleaseTime = itemView.findViewById(R.id.tvReleaseTime);
            tvQuestionText = itemView.findViewById(R.id.tvQuestionText);
            layoutLike = itemView.findViewById(R.id.layoutLike);
            tvLike = itemView.findViewById(R.id.tvLike);
            layoutComment = itemView.findViewById(R.id.layoutComment);
            tvComment = itemView.findViewById(R.id.tvComment);
        }
    }

    public interface OnClickAttentionListener {
        void onAttentionItemClick(int id, int position);
    }
}
