package com.kaapp.logic.idea;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.kaapp.R;

// 首页-想法-评论的适配器
public class IdeaDetailAdapter extends RecyclerView.Adapter {
    private Context context;

    public IdeaDetailAdapter(Context context) {
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder holder = new NormalViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_idea_detail_item, parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        NormalViewHolder normalHolder = (NormalViewHolder) holder;
//        ProductModel product = productList.get(position);
//        ImageUtils.loadImgByUrl(holder.ivLevelThumb, Res.http.picRoot + product.getPic1());
//        holder.tvLevelTitle.setText(product.getName());
//        holder.tvConsumeScore.setText(String.valueOf(product.getScore()));
    }

    @Override
    public int getItemCount() {
//        if (productList == null) {
//            return 0;
//        }
//        return productList.size();
        return 10;
    }


    public class NormalViewHolder extends RecyclerView.ViewHolder {
        // 正常Item
        private ImageView ivUserAvatar;
        private TextView tvUserName;
        private TextView tvReleaseTime;
        private TextView tvAnswerText;

        public NormalViewHolder(@NonNull View itemView) {
            super(itemView);
            ivUserAvatar = itemView.findViewById(R.id.ivUserAvatar);
            tvUserName = itemView.findViewById(R.id.tvUserName);
            tvReleaseTime = itemView.findViewById(R.id.tvReleaseTime);
            tvAnswerText = itemView.findViewById(R.id.tvAnswerText);
        }
    }
}
