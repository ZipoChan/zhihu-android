package com.kaapp.util;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	private static final String PATTERN1 = "yyyyMMddHHmmss";
	private static final String PATTERN2 = "yyyy-MM-dd HH:mm:ss";

	private DateUtil() {
	}

	public static Date stringToDate(String str) {
		final String[] fmt = { "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss" };
		for (String element : fmt) {
			DateFormat df = new SimpleDateFormat(element);
			try {
				Date d = df.parse(str);
				return d;
			} catch (ParseException e) {
			}
		}
		return null;
	}

	public static Calendar stringToCalendar(String str) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(stringToDate(str));
		return cal;
	}

	public static String format(Object o, String pattern) {
		if (o instanceof Date) {
			DateFormat df = new SimpleDateFormat(pattern);
			return df.format((Date) o);
		} else if (o instanceof Calendar) {
			DateFormat df = new SimpleDateFormat(pattern);
			return df.format(((Calendar) o).getTime());
		} else if (o instanceof String) {
			DateFormat df = new SimpleDateFormat(pattern);
			return df.format((stringToCalendar(String.valueOf(o))).getTime());
		}
		return "";
	}

	/**
	 * ISO 8601 formatter for date without time zone. The format used is
	 * {@code yyyy-MM-dd}.
	 */
	public static String toIsoDateFormat(Object o) {
		return DateFormatUtils.ISO_DATE_FORMAT.format(o);
	}

	/**
	 * ISO 8601 formatter for date-time without time zone. The format used is
	 * {@code yyyy-MM-dd'T'HH:mm:ss}.
	 */
	public static String toIsoDateTimeFormat(Object o) {
		return DateFormatUtils.ISO_DATETIME_FORMAT.format(o);
	}

	public static Date now() {
		return Calendar.getInstance().getTime();
	}

	/**
	 * ISO 8601 formatter for date-time without time zone. The format used is
	 * {@code yyyy-MM-dd'T'HH:mm:ss}.
	 */
	public static String nowIsoDateTimeFormat() {
		return toIsoDateTimeFormat(now());
	}

	public static boolean isDateFormat(String date) {
		if (!date.matches("[0-9]{4}/[0-9]{2}/[0-9]{2}")) {
			return false;
		}
		String reFormatDate = format(stringToDate(date), "yyyy/MM/dd");
		if (!date.equals(reFormatDate)) {
			return false;
		}
		return true;
	}

	public static String dispFormat(String date) {
		return format(stringToDate(date), PATTERN2);
	}

	public static String nowFormat() {
		return format(now(), PATTERN1);
	}
}
