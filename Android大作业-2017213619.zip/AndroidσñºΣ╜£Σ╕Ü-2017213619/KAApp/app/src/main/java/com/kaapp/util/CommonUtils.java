package com.kaapp.util;

public class CommonUtils {
    public static boolean isNull(Object object) {
        return object == null;
    }

    public static boolean isEmpty(CharSequence value) {
        return isNull(value) || value.length() == 0;
    }

    private CommonUtils() {
    }
}
