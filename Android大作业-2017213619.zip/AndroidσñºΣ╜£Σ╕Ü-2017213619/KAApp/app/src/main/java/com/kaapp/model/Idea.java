package com.kaapp.model;

import java.io.Serializable;

// 想法
public class Idea implements Serializable {
    private String ideaNo;
    private String question;
    private String answerText;
    private int likeCount;
    private int commentCount;
    private String userNo;
    private String createTime;

    public String getIdeaNo() {
        return ideaNo;
    }

    public void setIdeaNo(String ideaNo) {
        this.ideaNo = ideaNo;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
