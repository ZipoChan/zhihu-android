package com.kaapp.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.kaapp.BaseActivity;
import com.kaapp.R;
import com.kaapp.common.CameraEnum;
import com.kaapp.common.Res;
import com.kaapp.dialog.BottomCameraDialog;
import com.kaapp.manager.UserManager;
import com.kaapp.util.BitmapResizer;
import com.kaapp.util.CommonUtils;
import com.kaapp.util.FileHelper;
import com.kaapp.util.ImageUtils;
import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.FileProvider;
import com.yanzhenjie.permission.runtime.Permission;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;

// 注册页面
public class RegisterActivity extends BaseActivity implements BottomCameraDialog.CameraListener {

    private static final int REQUEST_FROM_CAMERA = 999;
    private static final int REQUEST_FROM_GALLERY = 1000;

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.ivAvatar)
    ImageView ivAvatar;
    @BindView(R.id.etUserNo)
    EditText etUserNo;
    @BindView(R.id.etUserName)
    EditText etUserName;
    @BindView(R.id.etPassword)
    EditText etPassword;
    @BindView(R.id.tvEnterOk)
    TextView tvEnterOk;

    private String filePath;
    private UserManager userManager;

    @Override
    protected int getLayout() {
        return R.layout.activity_register;
    }

    @Override
    protected void initView() {
        userManager = new UserManager(this);
        etUserNo.setText(userManager.queryMaxCode());
    }

    @OnClick({R.id.ivBack, R.id.ivAvatar, R.id.tvEnterOk})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivAvatar:
                onIvAvatarClick();
                break;
            case R.id.tvEnterOk:
                onTvEnterOkClick();
                break;
        }
    }

    private void onIvAvatarClick() {
        BottomCameraDialog dialog = new BottomCameraDialog(this);
        dialog.show();
    }

    // 注册
    private void onTvEnterOkClick() {
        String userNo = String.valueOf(etUserNo.getText());
        String userName = String.valueOf(etUserName.getText());
        String password = String.valueOf(etPassword.getText());
        if (TextUtils.isEmpty(filePath)) {
            showToast("头像未选择");
            return;
        }
        if (TextUtils.isEmpty(userNo) || TextUtils.isEmpty(userName) || TextUtils.isEmpty(password)) {
            showToast("内容不能为空");
            return;
        }

        // 向数据库保存数据
        ivAvatar.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(ivAvatar.getDrawingCache());
        ivAvatar.setDrawingCacheEnabled(false);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] byteImg = baos.toByteArray();
        long ret = userManager.addUser(userNo, userName, password, byteImg);
        if (0 < ret) {
            showToast("注册成功,请登录");
            finish();
        } else {
            showToast("注册失败");
        }
    }

    @Override
    public void onTakePhotoClickLister(final CameraEnum cameraEnum) {
        AndPermission.with(this)
                .runtime()
                .permission(Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE)
                .onGranted(new Action<List<String>>() {
                    @Override
                    public void onAction(List<String> data) {
                        // 调用相机
                        if (cameraEnum == CameraEnum.CAMERA) {
                            execCamera(REQUEST_FROM_CAMERA);
                        }
                        // 调用相册
                        else if (cameraEnum == CameraEnum.GALLEY) {
                            execGallery(REQUEST_FROM_GALLERY);
                        }
                    }
                }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_FROM_CAMERA || requestCode == REQUEST_FROM_GALLERY) {
            switch (requestCode) {
                case REQUEST_FROM_CAMERA:
                    getImageFromCamera();
                    break;
                case REQUEST_FROM_GALLERY:
                    getImageFromGallery(data);
                    File cameraFolder = new File(Res.url.media_tool_pic);
                    cameraFolder.mkdirs();
                    String fileName =
                            new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date());
                    String newPath = String.format("%s/%s.png", cameraFolder.getPath(), fileName);
                    FileHelper.copyFile(filePath, newPath);
                    break;
            }
            // 更新到本地
            if (TextUtils.isEmpty(filePath) == false) {
                ImageUtils.loadImgByUrl(ivAvatar, filePath);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void execCamera(int requestCode) {
        File cameraFolder = new File(Res.url.media_tool_pic);
        cameraFolder.mkdirs();
        String fileName =
                new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date());
        filePath = String.format("%s/%s.png", cameraFolder.getPath(), fileName);
        File cameraFile = new File(filePath);
        Uri uri = FileProvider.getUriForFile(this, getString(R.string.provider_name),
                cameraFile);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(intent, requestCode);
    }

    private void execGallery(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, requestCode);
    }

    private void getImageFromCamera() {
        Uri uri = ImageUtils.registerDatabase(this, filePath);
        getImage(uri);
    }

    private void getImageFromGallery(Intent data) {
        Uri uri = data.getData();
        if (ImageUtils.existDataColumn(this, uri) == false) {
            return;
        }
        getImage(uri);
    }

    private void getImage(Uri uri) {
        filePath = ImageUtils.getPathFromUri(this, uri);
        int maxSize = 40;
        BitmapResizer bitmapResizer = new BitmapResizer(this);
        Bitmap bitmap = bitmapResizer.resize(filePath, maxSize, maxSize);
        if (CommonUtils.isNull(bitmap)) {
            return;
        }
    }
}
