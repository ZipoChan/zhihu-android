package com.kaapp.model;

import java.io.Serializable;

// 问题
public class Question implements Serializable {
    private String questionNo;
    private String questionText;

    public String getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(String questionNo) {
        this.questionNo = questionNo;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }
}
