package com.kaapp.fragment;

import com.kaapp.BaseFragment;
import com.kaapp.R;

// 会员页
public class VipFragment extends BaseFragment {

    @Override
    protected int getLayout() {
        return R.layout.fragment_vip;
    }

    @Override
    protected void initView() {

    }

}
