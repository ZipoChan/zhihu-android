package com.kaapp;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.gyf.immersionbar.ImmersionBar;
import com.kaapp.util.SPUtils;
import com.smarx.notchlib.NotchScreenManager;

import butterknife.ButterKnife;
import butterknife.Unbinder;

// Activity基类
public abstract class BaseActivity extends AppCompatActivity {

    private Unbinder unbinder;
    protected NotchScreenManager notchScreenManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutInflater().inflate(getLayout(), null, true));
        // 沉浸式
        ImmersionBar.with(this).statusBarDarkFont(true, 0.2f).init();
        unbinder = ButterKnife.bind(this);
        notchScreenManager = NotchScreenManager.getInstance();
        initView();
    }

    protected abstract int getLayout();

    protected abstract void initView();

    @Override
    public Resources getResources() {
        Resources resources = super.getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.fontScale = 1.2f;
        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        return resources;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
    }

    protected void toLinkPage(Class<?> clazz) {
        Intent intent = new Intent();
        intent.setClass(this, clazz);
        startActivity(intent);
        finish();
    }

    protected void toLinkPageNotFinished(Class<?> clazz) {
        Intent intent = new Intent();
        intent.setClass(this, clazz);
        startActivity(intent);
    }

    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public String getMessageByRes(int resId) {
        return getResources().getString(resId);
    }

    public String getKey(String key) {
        return (String) SPUtils.get(this, key, "");
    }

    public void setKey(String key, String value) {
        SPUtils.put(this, key, value);
    }

    public String getStringFromRes(int resId) {
        return getResources().getString(resId);
    }

    public String[] getArraryFromRes(int resId) {
        return getResources().getStringArray(resId);
    }
}
