package com.kaapp.manager;

import android.content.Context;

import com.kaapp.db.DBManager;

// 想法
public class IdeaCommentManager extends DBManager {
    public static final String TABLE_NAME = "tb_idea";
    public static final String FIELD_IDEA_NO = "idea_no";
    public static final String FIELD_QUESTION = "question";
    public static final String FIELD_ANSWER_TEXT = "answer_text";
    public static final String FIELD_LIKE_COUNT = "like_count";
    public static final String FIELD_COMMENT_COUNT = "comment_count";
    public static final String FIELD_USER_NO = "user_no";
    public static final String FIELD_CREATE_TIME = "create_time";

    public IdeaCommentManager(Context context) {
        super(context);
    }

//    // 查询最大code
//    public String queryMaxCode() {
//        String maxCode = "";
//        String sqlCmd = " select info_no from tb_info order by info_no desc limit 1 ";
//        Cursor cursor = rawQuery(sqlCmd, null);
//        if (cursor != null) {
//            cursor.moveToPosition(-1);
//            while (cursor.moveToNext()) {
//                String userNo = cursor.getString(cursor.getColumnIndex(FIELD_INFO_NO));
//                String tmpCode = String.valueOf(Integer.parseInt(userNo) + 1);
//                maxCode = StringHelper.padLeft(tmpCode, 4);
//            }
//            cursor.close();
//        }
//        // 如果最大Code是空,则编号自动为"0001"
//        if (TextUtils.isEmpty(maxCode)) {
//            maxCode = "0001";
//        }
//        return maxCode;
//    }
}

