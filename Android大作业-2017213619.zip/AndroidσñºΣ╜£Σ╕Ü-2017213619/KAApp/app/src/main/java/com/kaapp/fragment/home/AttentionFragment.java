package com.kaapp.fragment.home;

import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.kaapp.BaseFragment;
import com.kaapp.R;
import com.kaapp.activity.home.AttentionDetailActivity;
import com.kaapp.logic.attention.AttentionAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import butterknife.BindView;

// 关注
public class AttentionFragment extends BaseFragment implements AttentionAdapter.OnClickAttentionListener {

    @BindView(R.id.srlAttention)
    SmartRefreshLayout srlAttention;
    @BindView(R.id.recyclerAttention)
    RecyclerView recyclerAttention;

    private AttentionAdapter adapter;

    @Override
    protected int getLayout() {
        return R.layout.fragment_attention;
    }

    @Override
    protected void initView() {
        initLayout();
        initListView();
        onLoad();
        srlAttention.autoRefresh();
    }

    private void initLayout() {
        srlAttention.setRefreshHeader(new ClassicsHeader(getActivity()));
        srlAttention.setEnableLoadMore(false);
    }

    private void initListView() {
        recyclerAttention.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new AttentionAdapter(getActivity(), this);
        recyclerAttention.setAdapter(adapter);
    }

    private void onLoad() {
        srlAttention.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                refreshLayout.finishRefresh();
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onAttentionItemClick(int id, int position) {
        // 回答页面
        if (id == R.id.layoutAttention) {
            toLinkPageNotFinished(AttentionDetailActivity.class);
        }
    }
}
