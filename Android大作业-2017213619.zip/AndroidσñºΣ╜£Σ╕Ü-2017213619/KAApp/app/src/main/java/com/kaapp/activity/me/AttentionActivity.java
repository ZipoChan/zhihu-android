package com.kaapp.activity.me;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.kaapp.BaseActivity;
import com.kaapp.R;
import com.kaapp.logic.me.UserAttentionAdapter;

import butterknife.BindView;
import butterknife.OnClick;

// 关注人列表
public class AttentionActivity extends BaseActivity implements UserAttentionAdapter.OnClickUserAttentionListener {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.recyclerAttentionUser)
    RecyclerView recyclerAttentionUser;

    private UserAttentionAdapter adapter;

    @Override
    protected int getLayout() {
        return R.layout.activity_attention;
    }

    @Override
    protected void initView() {
        initListView();
    }

    private void initListView() {
        recyclerAttentionUser.setLayoutManager(new LinearLayoutManager(this));
        adapter = new UserAttentionAdapter(this, this);
        recyclerAttentionUser.setAdapter(adapter);
    }

    @OnClick({R.id.ivBack})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivBack:
                finish();
                break;
        }
    }

    @Override
    public void onUserAttentionItemClick(int id, int position) {

    }
}
