package com.kaapp.activity.home;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.czy1121.view.ReadMoreTextView;
import com.kaapp.BaseActivity;
import com.kaapp.R;
import com.kaapp.dialog.BottomCommentDialog;
import com.kaapp.logic.idea.IdeaDetailAdapter;

import butterknife.BindView;
import butterknife.OnClick;

// 关注-想法
public class IdeaDetailActivity extends BaseActivity {

    // 返回
    @BindView(R.id.ivBack)
    ImageView ivBack;
    // 回答题目
    @BindView(R.id.tvReadMore)
    ReadMoreTextView tvReadMore;
    // 底部-点赞
    @BindView(R.id.layoutLike)
    LinearLayout layoutLike;
    @BindView(R.id.ivLike)
    ImageView ivLike;
    @BindView(R.id.tvLikeCount)
    TextView tvLikeCount;
    // 底部-评论
    @BindView(R.id.layoutComment)
    LinearLayout layoutComment;
    @BindView(R.id.ivComment)
    ImageView ivComment;
    @BindView(R.id.tvCommentCount)
    TextView tvCommentCount;
    @BindView(R.id.recyclerIdea)
    RecyclerView recyclerIdea;

    private IdeaDetailAdapter adapter;

    @Override
    protected int getLayout() {
        return R.layout.activity_idea_detail;
    }

    @Override
    protected void initView() {
        initListView();
    }

    private void initListView() {
        recyclerIdea.setLayoutManager(new LinearLayoutManager(this));
        adapter = new IdeaDetailAdapter(this);
        recyclerIdea.setAdapter(adapter);
    }

    @OnClick({R.id.ivBack, R.id.layoutLike, R.id.layoutComment})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.layoutLike:
                onIvLikeClick();
                break;
            case R.id.layoutComment:
                onIvCommentClick();
                break;
        }
    }

    // 底部-点赞
    private void onIvLikeClick() {

    }

    // 底部-评论
    private void onIvCommentClick() {
//        BottomCommentDialog dialog = new BottomCommentDialog(this);
//        dialog.show();
    }
}
