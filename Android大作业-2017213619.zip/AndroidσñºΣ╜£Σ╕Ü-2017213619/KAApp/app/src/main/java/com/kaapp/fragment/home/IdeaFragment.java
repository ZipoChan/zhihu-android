package com.kaapp.fragment.home;

import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.kaapp.BaseFragment;
import com.kaapp.R;
import com.kaapp.activity.home.IdeaDetailActivity;
import com.kaapp.logic.idea.IdeaAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import butterknife.BindView;

// 想法
public class IdeaFragment extends BaseFragment implements IdeaAdapter.OnClickAttentionListener {

    @BindView(R.id.srlIdea)
    SmartRefreshLayout srlIdea;
    @BindView(R.id.recyclerIdea)
    RecyclerView recyclerIdea;

    private IdeaAdapter adapter;

    @Override
    protected int getLayout() {
        return R.layout.fragment_idea;
    }

    @Override
    protected void initView() {
        initLayout();
        initListView();
        onLoad();
        srlIdea.autoRefresh();
    }

    private void initLayout() {
        srlIdea.setRefreshHeader(new ClassicsHeader(getActivity()));
        srlIdea.setEnableLoadMore(false);
    }

    private void initListView() {
        recyclerIdea.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new IdeaAdapter(getActivity(), this);
        recyclerIdea.setAdapter(adapter);
    }

    private void onLoad() {
        srlIdea.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                refreshLayout.finishRefresh();
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onAttentionItemClick(int id, int position) {
        toLinkPageNotFinished(IdeaDetailActivity.class);
    }
}
