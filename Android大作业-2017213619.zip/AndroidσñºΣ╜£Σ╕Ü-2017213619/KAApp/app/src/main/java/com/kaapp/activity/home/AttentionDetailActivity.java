package com.kaapp.activity.home;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kaapp.BaseActivity;
import com.kaapp.R;
import com.kaapp.common.ConfirmEnum;
import com.kaapp.dialog.BottomAnswerDialog;
import com.kaapp.dialog.BottomCommentDialog;

import butterknife.BindView;
import butterknife.OnClick;

// 关注-回答
public class AttentionDetailActivity extends BaseActivity implements BottomAnswerDialog.ConfirmListener {

    // 返回
    @BindView(R.id.ivBack)
    ImageView ivBack;
    // 回答题目
    @BindView(R.id.tvQuestionText)
    TextView tvQuestionText;
    // 回头人头像
    @BindView(R.id.ivUserAvatar)
    ImageView ivUserAvatar;
    // 回答人姓名
    @BindView(R.id.tvUserName)
    TextView tvUserName;
    // 时间
    @BindView(R.id.tvReleaseTime)
    TextView tvReleaseTime;
    // 关注按钮
    @BindView(R.id.btnAttention)
    Button btnAttention;
    // 回答内容
    @BindView(R.id.tvAnswerText)
    TextView tvAnswerText;
    // 下一个回答
    @BindView(R.id.ivNextAnswer)
    ImageView ivNextAnswer;
    // 底部-写回答
    @BindView(R.id.tvWriteAnswer)
    TextView tvWriteAnswer;
    // 底部-点赞
    @BindView(R.id.layoutLike)
    LinearLayout layoutLike;
    @BindView(R.id.ivLike)
    ImageView ivLike;
    @BindView(R.id.tvLikeCount)
    TextView tvLikeCount;
    // 底部-评论
    @BindView(R.id.layoutComment)
    LinearLayout layoutComment;
    @BindView(R.id.ivComment)
    ImageView ivComment;
    @BindView(R.id.tvCommentCount)
    TextView tvCommentCount;

    @Override
    protected int getLayout() {
        return R.layout.activity_attention_detail;
    }

    @Override
    protected void initView() {

    }

    @OnClick({R.id.ivBack, R.id.ivNextAnswer, R.id.tvWriteAnswer, R.id.layoutLike, R.id.layoutComment})
    public void onClickView(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.ivBack:
                finish();
                break;
            case R.id.ivNextAnswer:
                onIvNextAnswerClick();
                break;
            case R.id.tvWriteAnswer:
                onTvWriteAnswerClick();
                break;
            case R.id.layoutLike:
                onIvLikeClick();
                break;
            case R.id.layoutComment:
                onIvCommentClick();
                break;
        }
    }

    // 下一个回答
    private void onIvNextAnswerClick() {

    }

    // 底部-写回答
    private void onTvWriteAnswerClick() {
        BottomAnswerDialog dialog = new BottomAnswerDialog(this);
        dialog.show();
    }

    // 底部-点赞
    private void onIvLikeClick() {

    }

    // 底部-评论
    private void onIvCommentClick() {
    }

    // 底部-写回答回调
    @Override
    public void onConfirmClickLister(ConfirmEnum confirmEnum, String value) {

    }
}
