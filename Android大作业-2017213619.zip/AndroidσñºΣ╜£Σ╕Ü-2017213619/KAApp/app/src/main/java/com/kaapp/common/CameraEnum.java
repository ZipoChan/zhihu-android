package com.kaapp.common;

public enum CameraEnum {
    CAMERA,
    GALLEY,
    CANCEL;
}
