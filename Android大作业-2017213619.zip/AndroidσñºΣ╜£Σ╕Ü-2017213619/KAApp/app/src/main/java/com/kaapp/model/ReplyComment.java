package com.kaapp.model;

import java.io.Serializable;

// 回答评论
public class ReplyComment implements Serializable {
    private String replyCommentNo;
    private String answerText;
    private int likeCount;
    private String userNo;
    private String questionNo;
    private String replyNo;
    private String createTime;
    private User user;

    public String getReplyCommentNo() {
        return replyCommentNo;
    }

    public void setReplyCommentNo(String replyCommentNo) {
        this.replyCommentNo = replyCommentNo;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getReplyNo() {
        return replyNo;
    }

    public void setReplyNo(String replyNo) {
        this.replyNo = replyNo;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(String questionNo) {
        this.questionNo = questionNo;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
