package com.kaapp.model;

import java.io.Serializable;

// 想法评论
public class IdeaComment implements Serializable {
    private String ideaCommentNo;
    private String answerText;
    private int likeCount;
    private String userNo;
    private String createTime;
    private String ideaNo;

    public String getIdeaCommentNo() {
        return ideaCommentNo;
    }

    public void setIdeaCommentNo(String ideaCommentNo) {
        this.ideaCommentNo = ideaCommentNo;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getIdeaNo() {
        return ideaNo;
    }

    public void setIdeaNo(String ideaNo) {
        this.ideaNo = ideaNo;
    }
}
