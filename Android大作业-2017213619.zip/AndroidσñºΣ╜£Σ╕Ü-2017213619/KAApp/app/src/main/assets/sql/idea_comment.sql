create table tb_idea_comment(
    idea_comment_no       varchar(50)    ,
    answer_text    varchar(500)   ,
    like_count     INTEGER            ,
    user_no        varchar(50)    ,
    create_time    varchar(14)    ,
    idea_no        varchar(50)     ,
    constraint tb_idea_comment_primary primary key(
        idea_comment_no
   )
);