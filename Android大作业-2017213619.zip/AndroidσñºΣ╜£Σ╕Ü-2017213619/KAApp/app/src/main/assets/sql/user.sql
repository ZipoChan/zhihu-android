create table tb_user(
    user_no        varchar(50)         ,
    user_name      varchar(20)         ,
    password       varchar(20)         ,
    avatar         blob                ,
    constraint tb_user_primary primary key(
        user_no
   )
);