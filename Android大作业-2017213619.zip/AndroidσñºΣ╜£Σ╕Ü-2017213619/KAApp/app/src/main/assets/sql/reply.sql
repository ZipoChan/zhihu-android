create table tb_reply(
    reply_no       varchar(50)    ,
    question_no    varchar(500)    ,
    answer_text    varchar(500)   ,
    like_count     INTEGER            ,
    comment_count  INTEGER            ,
    user_no        varchar(50)    ,
    create_time    varchar(14)    ,
    constraint tb_reply_primary primary key(
        reply_no
   )
);
