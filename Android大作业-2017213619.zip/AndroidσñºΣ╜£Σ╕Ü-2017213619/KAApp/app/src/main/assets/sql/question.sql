create table tb_question(
    question_no    varchar(50)    ,
    question_text  varchar(500)   ,
    constraint tb_question_primary primary key(
        question_no
   )
);