create table tb_idea(
    idea_no       varchar(50)     ,
    question       varchar(500)   ,
    answer_text    varchar(500)   ,
    like_count     INTEGER            ,
    comment_count  INTEGER            ,
    user_no        varchar(50)    ,
    create_time    varchar(14)    ,
    constraint tb_idea_primary primary key(
        idea_no
   )
);