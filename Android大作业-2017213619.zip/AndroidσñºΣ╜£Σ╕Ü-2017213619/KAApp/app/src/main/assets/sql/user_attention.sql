create table tb_attention(
    attention_no   varchar(20)         ,
    user_no        varchar(20)         ,
    other_no       varchar(20)         ,
    constraint tb_attention_primary primary key(
        attention_no
   )
);