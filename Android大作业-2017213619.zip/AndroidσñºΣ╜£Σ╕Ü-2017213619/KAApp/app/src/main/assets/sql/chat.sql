create table tb_chat(
    chat_id        INTEGER not null primary key AUTOINCREMENT    ,
    sender_no      varchar(50)    ,
    receiver_no    varchar(50)    ,
    create_time    varchar(14)
);
